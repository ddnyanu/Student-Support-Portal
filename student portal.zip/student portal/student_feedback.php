<?php

include('head.php');
include('navbar.php');

?>

    
     <div class="container-fluid" style="background-image: url('assest/student1.jpg');background-size: 100% 100%;">
       <div class="row">

         <div class="col-md-12 mt-5 text-center"><button  style="background-color:  #e6f5ff;filter: opacity(40%);color: red"; type="button" class="btn btn-light" data-toggle="modal" data-target="#modalid"><h4>Add Your Feedback</h4></button></div>
       </div>

       <div class="modal w-50 h-100 " id="modalid" style="margin-left:400px;margin-top: 150px;">
          <div class="modal-dailog">
          <div class="modal-content">
            <div class="modal-header bg-primary"><h4 class="text-white">Student Feedback From</h4>
        <button class=" btn btn-warning" data-dismiss="modal">close</button>

            </div>

            <div class="modal-body">
            <form action="student_feedback.php" method="post" enctype="multipart/form-data">
               <div class="row">

               <div class="col-md-6">
                 <label>Photo:</label>
                 <input type="file" name="photo" class="form-control" required>
               </div>

               <div class="col-md-6">
                 <label>Name:</label>
                 <input type="text" name="name" class="form-control" required>
               </div>
   
               <div class="col-md-6">
                 <label>address:</label>
                 <input type="text" name="address" class="form-control" required>
                 
               </div>


               <div class="col-md-6">
                 <label>class:</label>
                 <input type="text" name="class" class="form-control" required>
               </div>


               <div class="col-md-6 mt-2">
                 <label>messege:</label>
                <textarea name="messege" class="form-control"></textarea>
               </div>

               <div class="col-md-12 text-center mt-2">
                 <button class="btn btn-warning" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Submit</button>
               </div>


               



             </div>
            </form>

            </div>
            </div>
          </div></div>
          









      
      <div class="row mt-5">
<?php
include('database/database.php');

  $query = "SELECT * from feedback";
 $fire=mysqli_query($conn,$query);
 $i=1;
 while ($row = mysqli_fetch_assoc($fire)) {


        ?>

        <div class="col-md-3 mb-5">
          <div class="card" style="background-color:  #e6f5ff;filter: opacity(70%);">
            <div class="card-body">
            
            <div class="col-md-12 text-center mb-3">
                <img src="admin/upload/<?=$row['photo'];?>" width="100px"style="border-radius: 50%;">
              </div>

              <div class="col-md-12 text-center">
                <h5 class="text-primary font-weight-bold"><?=$row['name'];?></h5>
              </div>


              <div class="col-md-12 text-center">
                <h5 class="text-primary font-weight-bold"><?=$row['class'];?></h5>
              </div>

              <div class="col-md-12 text-center"><h5 class="text-primary font-weight-bold"><?=$row['address'];?></h5></div>

                <div class="col-md-12 text-center">
                
                <p class="text-dark font-weight-bold"><?=$row['messege'];?></p>
              </div>

           

            </div>
          </div>

        </div>

        <?php 
      }
      ?>

      </div><!--  row close -->


       </div>
     </div><!--  container close -->
  


         </body>
       </html>



<?php 
echo "<pre>";

// print_r($_POST);
// print_r($_FILES);
 include('database/database.php');
 
function image($name,$size,$temp,$path)
{
$ext=explode(".",$name);
$a=rand(1,9999)."-feedback.".$ext[count($ext)-1];
move_uploaded_file($temp,"$path".$a);
return $a;

}

if (isset($_POST['name'])) {

$name=$_FILES['photo']['name'];
$size=$_FILES['photo']['size'];
$tmp=$_FILES['photo']['tmp_name'];
$path="admin/upload/";
$photo=image($name,$size,$tmp,$path);

  


$query ="INSERT INTO feedback(photo, name, address, class, messege) VALUES ('".$photo."','".$_POST['name']."','".$_POST['address']."','".$_POST['class']."','".$_POST['messege']."')";

$fire =mysqli_query($conn,$query);
if ($fire) {
        echo "<script>alert('Data insert Successfully...');window.location.href='student_feedback.php';</script>";
  
}
else{
  echo "error";
}

}



?>