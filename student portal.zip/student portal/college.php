<?php

include('head.php');
include('navbar.php');
include('database/database.php');

?>



<marquee scrollamount="20"><h1 class="ml-5 mt-2"><i>Welcome Studnet Support Portal</i> <span></span></h1></marquee>

<div class="container background">

  

<?php 

include('database/database.php');
$query = "SELECT * from college";
 $fire=mysqli_query($conn,$query);

 while ($row = mysqli_fetch_assoc($fire)) {
  




?><div class="row">


    <div class="col-md-12">
      <p>
  <button class="btn btn-info btn-lg" type="button" data-toggle="collapse" data-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
   <?=$row['clg_name'];?>
  </button>
</p>
<div style="min-height: 120px;">
  <div class="collapse width" id="collapseWidthExample">
    <div class="card card-body" style="width:100%;">

    <div class="row">
        <div class="col-md-2">
        <img  src="admin/upload/<?=$row['clg_logo'];?>" width="150px">
      </div>

      <div class="col-md-8">
        <h3><span class="text-danger">College Name: </span><?=$row['clg_name'];?></h3>
        <h3><span class="text-danger">Address: </span><?=$row['clg_address'];?></h3>
        <h3><span class="text-danger">Grade: </span><?=$row['clg_grade'];?></h3>
      </div>

    </div>

      <!-- <h5>  Grade :- A<sup>+</sup></h5> -->


      <div class="row">

        <div class="col-md-6  text-center mt-5">

          <div class="col-md-12">
            <h5>Courses</h5>
          </div>

          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_1'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_2'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_3'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_4'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_5'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_6'];?></h5>        
          </div>



          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_7'];?></h5>        
          </div>



          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_8'];?></h5>        
          </div>



          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_9'];?></h5>        
          </div>


          <div class="col-md-12 course">
          <h5 class="text-primary"><?=$row['cname_10'];?></h5>        
          </div>


        </div> <!-- col 6 end -->



        <!-- fees -->

        <div class="col-md-6 mt-5 text-center">

          <div class="col-md-12">
            <h5>Fees</h5>
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_1'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_2'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_3'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_4'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_5'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_6'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_7'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_8'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_9'];?></h5>        
          </div>

          <div class="col-md-12 course"> 
          <h5><?=$row['cfees_10'];?></h5>        
          </div>


        </div> <!--  col 6 end  -->


      </div> <!--  row end -->


  
 
      <h2 class="mt-5">Facilities:-</h2>
      

       

      
     <ul class="Facilities">
     
       <li><?=$row['facilites_1'];?></li>
       <li><?=$row['facilites_2'];?></li>
       <li><?=$row['facilites_3'];?></li>
       <li><?=$row['facilites_4'];?></li>
       <li><?=$row['facilites_5'];?></li>
       <li><?=$row['facilites_6'];?></li>
      
     </ul>
    

    <h2>Campus</h2>

   <div class="row">

     <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_1'];?>" width="100%">
      
    </div>

    <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_2'];?>" width="100%">
       </p>
    </div>


    <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_3'];?>" width="100%">
    </div>


    <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_4'];?>" width="100%">
      
    </div> 

    <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_5'];?>" width="100%">
     
    </div>

    <div class="col-md-4 campus">
      <img src="admin/upload/<?=$row['img_6'];?>" width="100%">
     
    </div>

    <div class="col-md-12 mt-5">
     <a href="https://acscollegesonai.edu.in/"> <button class="btn-lg btn-primary">View More</button></a>
    </div>


     
   </div><!-- row closee -->


     


    </div>


  </div>
     <?php 
    }  ?>



       
</div>

    </div>





  </div>
</div>

 
</script>

</body>
</html>