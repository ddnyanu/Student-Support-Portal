<?php 
echo "<pre>";
// print_r($_POST);
// print_r($_FILES);


include('../database/database.php');
 

function image($name,$size,$temp,$path)
{
$ext=explode(".",$name);
$a=rand(1,9999)."-job.".$ext[count($ext)-1];
move_uploaded_file($temp,"$path".$a);
return $a;

}


if (isset($_POST['c_title'])){
	
$name=$_FILES['c_logo']['name'];
$size=$_FILES['c_logo']['size'];
$tmp=$_FILES['c_logo']['tmp_name'];
$path="upload/";
$c_logo=image($name,$size,$tmp,$path);


$query ="INSERT INTO job(c_logo,c_name,c_title, c_experience, c_qulification, passing_year, salary, salary_type,link) VALUES ('".$c_logo."','".$_POST['c_name']."','".$_POST['c_title']."','".$_POST['c_experience']."','".$_POST['c_qulification']."','".$_POST['passing_year']."','".$_POST['salary']."','".$_POST['salary_type']."','".$_POST['link']."')";

$fire =mysqli_query($conn,$query);

if ($fire) {
 echo "<script>alert('Data insert Successfully...');window.location.href='job_details.php';</script>";
	
}
else{
	echo "error";
}
}





// update

?>