
<?php 

include('head.php');
include('cdn.php');

?>

<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>


  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Feedback</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->


    <div class="container">
    	<div class="row">
    		
    		<div class="col-md-12">
				<p>
				<a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
				Feedback record
				</a>
				</p>

    		

    	
<div class="collapse" id="collapseExample">
  <div class="card card-body">
 
    <table class="table table-hover table-stripped table-calender">
    	
        <tr>
        	<th>sr.no</th>
        	<th>photo</th>
        	<th>name</th>
        	<th>address</th>
        	<th>class</th>
        	<th>meseege</th>
        	<th>edit</th>
        </tr>

        <?php 

  $query = "SELECT * from feedback";
 include('../database/database.php');
 $fire=mysqli_query($conn,$query);
 $i=1;
 while ($row = mysqli_fetch_assoc($fire)) {


        ?>
        <form action="feedback.php" method="post" enctype="multipart/form-data">

        <tr><td><?=$i++;?>
          <input type="hidden" name="id" value="<?=$row['id'];?>">
          <input type="hidden" name="photo" value="<?=$row['photo'];?>">
        </td>
        	<td><img src="upload/<?=$row['photo'];?>" width="100px"></td>
        	<td><input type="text" name="name1" value="<?=$row['name'];?>" class="form-control"></td>
        	<td><input type="text" name="address" value="<?=$row['address'];?>" class="form-control"></td>
        	<td><input type="text" name="class" value="<?=$row['class'];?>" class="form-control"></td>
        	<td><input type="text" name="messege" value="<?=$row['messege'];?>" class="form-control"></td>
          <td>
            <a href=""><button class="btn btn-warning">Edit</button></a>
            <a href="feedback.php?deleteid=<?=$row['id'];?>&img=<?=$row['photo'];?>"><button type="button" class="btn btn-danger">Remove</button></a>
          </td>
        </tr>
     </form>
        <?php 
      }
        ?>

    </table>


  </div>
  </div>

</div>


    	</div>
    </div>

   

  </main><!-- End #main -->

</body>
</html>


<?php 

  // update
include('../database/database.php');

if (isset($_POST['name1'])) {
$query ="UPDATE feedback SET name='".$_POST['name1']."',address='".$_POST['address']."',class='".$_POST['class']."',messege='".$_POST['messege']."' WHERE id='".$_POST['id']."'";

$fire=mysqli_query($conn,$query);
if ($fire) {
 echo "<script>alert('Data update Successfully...');window.location.href='feedback.php';</script>";
  
}
else{
  echo "eroor";
}

}

// delete.

  if (isset($_GET['deleteid'])) {
  
    $query ="DELETE FROM feedback where id='".$_GET['deleteid']."'";
    $path ='upload/'.$_GET['img'];
       unlink($path);
       $fire =mysqli_query($conn,$query);

      if ($fire) {
 echo "<script>alert('Data delete Successfully...');window.location.href='feedback.php';</script>";

         
       } 
       else{
        echo "error";
       }
 }




?>








