<?php 
echo "<pre>";
// print_r($_POST);
// print_r($_FILES);

 $conn=mysqli_connect('localhost','root','','portal');
 

function image($name,$size,$temp,$path)
{
$ext=explode(".",$name);
$a=rand(1,9999)."-college_datails.".$ext[count($ext)-1];
move_uploaded_file($temp,"$path".$a);
return $a;

}



if (isset($_POST['clg_name'])) {
    extract($_POST);


$name=$_FILES['clg_logo']['name'];
$size=$_FILES['clg_logo']['size'];
$tmp=$_FILES['clg_logo']['tmp_name'];
$path="upload/";
$clg_logo=image($name,$size,$tmp,$path);

$name=$_FILES['img_1']['name'];
$size=$_FILES['img_1']['size'];
$tmp=$_FILES['img_1']['tmp_name'];
$path="upload/";
$img_1=image($name,$size,$tmp,$path);


$name=$_FILES['img_2']['name'];
$size=$_FILES['img_2']['size'];
$tmp=$_FILES['img_2']['tmp_name'];
$path="upload/";
$img_2=image($name,$size,$tmp,$path);



$name=$_FILES['img_3']['name'];
$size=$_FILES['img_3']['size'];
$tmp=$_FILES['img_3']['tmp_name'];
$path="upload/";
$img_3=image($name,$size,$tmp,$path);



$name=$_FILES['img_4']['name'];
$size=$_FILES['img_4']['size'];
$tmp=$_FILES['img_4']['tmp_name'];
$path="upload/";
$img_4=image($name,$size,$tmp,$path);



$name=$_FILES['img_5']['name'];
$size=$_FILES['img_5']['size'];
$tmp=$_FILES['img_5']['tmp_name'];
$path="upload/";
$img_5=image($name,$size,$tmp,$path);


$name=$_FILES['img_6']['name'];
$size=$_FILES['img_6']['size'];
$tmp=$_FILES['img_6']['tmp_name'];
$path="upload/";
$img_6=image($name,$size,$tmp,$path);



$query ="INSERT INTO college(clg_name, clg_logo, clg_grade, clg_address, cname_1,  cfees_1, cname_2, cfees_2, cname_3,  cfees_3,  cname_4, cfees_4, cname_5, cfees_5,  cname_6,  cfees_6, cname_7,  cfees_7, cname_8,  cfees_8, cname_9,  cfees_9, cname_10,  cfees_10,facilites_1, facilites_2, facilites_3, facilites_4, facilites_5, facilites_6, img_1, img_2, img_3, img_4, img_5, img_6) VALUES ('".$clg_name."','".$clg_logo."','".$clg_grade."','".$clg_address."','".$cname_1."','".$cfees_1."','".$cname_2."','".$cfees_2."','".$cname_3."','".$cfees_3."','".$cname_4."','".$cfees_4."','".$cname_5."','".$cfees_5."','".$cname_6."','".$cfees_6."','".$cname_7."','".$cfees_7."','".$cname_8."','".$cfees_8."','".$cname_9."','".$cfees_9."','".$cname_10."','".$cfees_10."','".$facilites_1."','".$facilites_2."','".$facilites_3."','".$facilites_4."','".$facilites_5."','".$facilites_6."','".$img_1."','".$img_2."','".$img_3."','".$img_4."','".$img_5."','".$img_6."')";


	



		$fire=mysqli_query($conn,$query);
		if ($fire) {
        echo "<script>alert('Data insert Successfully...');window.location.href='college_details.php';</script>";
			
		}

		else{
			echo"insert error";
		}

}


  
     // update
    if(isset($_POST['clg_name1'])){
    if($_FILES['clg_logo']['name']!=""){
        $name=$_FILES['clg_logo']['name'];
        $size=$_FILES['clg_logo']['size'];
        $tmp=$_FILES['clg_logo']['tmp_name'];
        $path="upload/";
        $img=image($name,$size,$tmp,$path);
        $path0='upload/'.$_POST['clg_logo'];
        unlink($path0);
    }
    else{
        $img=$_POST['clg_logo'];
    }

    if($_FILES['img_1']['name']!=""){
        $name=$_FILES['img_1']['name'];
        $size=$_FILES['img_1']['size'];
        $tmp=$_FILES['img_1']['tmp_name'];
        $path="upload/";
        $img1=image($name,$size,$tmp,$path);
        $path1='upload/'.$_POST['img_1'];
        unlink($path1);
    }
    else{
        $img1=$_POST['img_1'];
    }


    if($_FILES['img_2']['name']!=""){
        $name=$_FILES['img_2']['name'];
        $size=$_FILES['img_2']['size'];
        $tmp=$_FILES['img_2']['tmp_name'];
        $path="upload/";
        $img2=image($name,$size,$tmp,$path);
        $path2='upload/'.$_POST['img_2'];
        unlink($path2);
    }
    else{
        $img2=$_POST['img_2'];
    }


    if($_FILES['img_3']['name']!=""){
        $name=$_FILES['img_3']['name'];
        $size=$_FILES['img_3']['size'];
        $tmp=$_FILES['img_3']['tmp_name'];
        $path="upload/";
        $img3=image($name,$size,$tmp,$path);
        $path3='upload/'.$_POST['img_3'];
        unlink($path3);
    }
    else{
        $img3=$_POST['img_3'];
    }


    if($_FILES['img_4']['name']!=""){
        $name=$_FILES['img_4']['name'];
        $size=$_FILES['img_4']['size'];
        $tmp=$_FILES['img_4']['tmp_name'];
        $path="upload/";
        $img4=image($name,$size,$tmp,$path);
        $path4='upload/'.$_POST['img_4'];
        unlink($path4);
    }
    else{
        $img4=$_POST['img_4'];
    }


    if($_FILES['img_5']['name']!=""){
        $name=$_FILES['img_5']['name'];
        $size=$_FILES['img_5']['size'];
        $tmp=$_FILES['img_5']['tmp_name'];
        $path="upload/";
        $img5=image($name,$size,$tmp,$path);
        $path5='upload/'.$_POST['img_5'];
        unlink($path5);
    }
    else{
        $img5=$_POST['img_5'];
    }


    if($_FILES['img_6']['name']!=""){
        $name=$_FILES['img_6']['name'];
        $size=$_FILES['img_6']['size'];
        $tmp=$_FILES['img_6']['tmp_name'];
        $path="upload/";
        $img6=image($name,$size,$tmp,$path);
        $path6='upload/'.$_POST['img_6'];
        unlink($path6);
    }
    else{
        $img6=$_POST['img_6'];
    }






$query ="UPDATE college SET clg_name='".$_POST['clg_name1']."',clg_logo='".$img."',clg_grade='".$_POST['clg_grade']."',clg_address='".$_POST['clg_address']."',cname_1='".$_POST['cname_1']."',cfees_1='".$_POST['cfees_1']."',cname_2='".$_POST['cname_2']."',cfees_2='".$_POST['cfees_2']."',cname_3='".$_POST['cname_3']."',cfees_3='".$_POST['cfees_3']."',cname_4='".$_POST['cname_4']."',cfees_4='".$_POST['cfees_4']."',cname_5='".$_POST['cname_5']."',cfees_5='".$_POST['cfees_5']."',cname_6='".$_POST['cname_6']."',cfees_6='".$_POST['cfees_6']."',cname_7='".$_POST['cname_7']."',cfees_7='".$_POST['cfees_7']."',cname_8='".$_POST['cname_8']."',cfees_8='".$_POST['cfees_8']."',cname_9='".$_POST['cname_9']."',cfees_9='".$_POST['cfees_9']."',cname_10='".$_POST['cname_10']."',cfees_10='".$_POST['cfees_10']."',facilites_1='".$_POST['facilites_1']."',facilites_2='".$_POST['facilites_2']."',facilites_3='".$_POST['facilites_3']."',facilites_4='".$_POST['facilites_4']."',facilites_5='".$_POST['facilites_5']."',facilites_6='".$_POST['facilites_6']."',img_1='".$img1."',img_2='".$img2."',img_3='".$img3."',img_4='".$img4."',img_5='".$img5."',img_6='".$img6."' WHERE id='".$_POST['id']."'";	


	$fire=mysqli_query($conn,$query);
	if ($fire) {
        echo "<script>alert('Data Updated Successfully...');window.location.href='college_details.php';</script>";
		
	}

	else{
		echo "error";
	}

}


   // delete 

    if (isset($_GET['deleteid'])) {
       $query= "DELETE FROM college where id='".$_GET['deleteid']."'";

       $path ='upload/'.$_GET['logo'];
       unlink($path);

        $path1 ='upload/'.$_GET['img1'];
       unlink($path1);


        $path2 ='upload/'.$_GET['img2'];
       unlink($path2);


        $path3 ='upload/'.$_GET['img3'];
       unlink($path3);


        $path4 ='upload/'.$_GET['img4'];
       unlink($path4);


        $path5 ='upload/'.$_GET['img5'];
       unlink($path5);


        $path6 ='upload/'.$_GET['img6'];
       unlink($path6);


       $fire =mysqli_query($conn,$query);
       if($fire){
  echo "<script>alert('Successfully Delete Data');window.location.href='college_details.php';</script>";
}
else{
    echo "error";
}
}





?>