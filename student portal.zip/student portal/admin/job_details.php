<?php 

include('head.php');
include('cdn.php');

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>


  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Job Details</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <div class="container">
    	<div class="row">

    		<div class="col-md-12">
    			<button class="btn btn-warning dropdown" data-toggle="collapse" href="#Add_clg" role="button" aria-expanded="false" aria-controls="Add_clg">Add New Job</button>
    		</div>

    		<div class="collapse" id="Add_clg">
    			 
    			  <div class="card card-body">
            <form action="job_query.php" method="post" enctype="multipart/form-data">
              <div class="container">
                <div class="row">
                  
                  <div class="col-md-6">
                    <label>Company Logo</label>
                    <input type="file" name="c_logo" class="form-control">
                  </div>

                  <div class="col-md-6">
                    <label>Company name</label>
                    <input type="text" name="c_name" class="form-control">
                  </div>


                   <div class="col-md-6">
                    <label>Job Title</label>
                    <input type="text" name="c_title" class="form-control">
                  </div>

                  <div class="col-md-6">
                    <label>Experience</label>
                    <input type="text" name="c_experience" class="form-control">
                  </div>


                  <div class="col-md-6">
                    <label>Qulification</label>
                    <input type="text" name="c_qulification" class="form-control">
                  </div>


                  <div class="col-md-6">
                    <label>Year of Passing</label>
                    <input type="text" name="passing_year" class="form-control">
                  </div>


                  <div class="col-md-6">
                    <label>Salary</label>
                   <span><input type="text" name="salary" class="form-control"> 
                    <select name="salary_type">
                      <option>Per Annum</option>
                      <option>Package</option>
                    </select>
                  </span> 
                  
                  </div>

                  <div class="col-md-6">
                    <label>Link</label>
                    <input type="text" name="link" class="form-control">
                  </div>

                  <div class="col-md-12">
                    <button class="btn btn-warning">Submit</button>
                  </div>



                </div>
              </div> 
              </form>

    			  	
    			  </div> <!-- card  -->

    		</div>


        <div class="col-md-12">

          <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
  job record
  </a>
  
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">

    <table class="table table-hover table-calender table-stripped">
      <tr>
        <th>sr.no</th>
        <th>College Logo</th>
        <th>Company name</th>
        <th>Job name</th>
        <th>Experience</th>
        <th>Qulification</th>
        <th>Year of Passing</th>
        <th>Salary</th>
        <th>salary_type</th>
        <th>link</th>
        <th>edit</th>
      </tr>

      <?php 
 $query = "SELECT * from job";
 include('../database/database.php');
 $fire=mysqli_query($conn,$query);
 $i=1;
 while ($row = mysqli_fetch_assoc($fire)) {


?>

     <form action="job_details.php" method="post" enctype="multipart/form-data">

      <tr>

        <td>
          <input type="hidden" name="id" value="<?=$row['id'];?>">
          <input type="hidden" name="c_logo" value="<?=$row['c_logo'];?>">
          <?=$i++;?></td>
        <td><input type="file" name="c_logo" class="form-control"><img src="upload/<?=$row['c_logo'];?>" width="100px";></td>
        <td><input type="text" name="c_name1" value="<?=$row['c_name'];?>"></td>
        <td><input type="text" name="c_title" value="<?=$row['c_title'];?>" class="form-control"></td>
        <td><input type="text" name="c_experience" value="<?=$row['c_experience'];?>" class="form-control"></td>
        <td><input type="text" name="c_qulification" value="<?=$row['c_qulification'];?>" class="form-control"></td>
        <td><input type="text" name="passing_year" value="<?=$row['passing_year'];?>" class="form-control"></td>
        <td><input type="text" name="salary" value="<?=$row['salary'];?>" class="form-control"></td>
        <td><input type="text" name="salary_type" value="<?=$row['salary_type'];?>" class="form-control"></td>
        <td><input type="text" name="link" value="<?=$row['link'];?>"></td>
        <td><a href=""><button class="btn btn-warning">edit</button></a>

          <a href="job_details.php?deleteid=<?=$row['id'];?>&img=<?=$row['c_logo'];?>"><button type="button" class="btn btn-danger">remove</button></a>
        </td>
      
      </tr>
    </form>
    <?php 
  }
  ?>



    </table>
    
  </div>
</div>
          
        </div> <!-- col md 12 close -->




</div>  <!-- rows -->
</div>   <!-- container close -->

   

  </main><!-- End #main -->


</body>
</html>

<?php 
include('../database/database.php');

function image($name,$size,$temp,$path)
{
$ext=explode(".",$name);
$a=rand(1,9999)."-job.".$ext[count($ext)-1];
move_uploaded_file($temp,"$path".$a);
return $a;

}

if (isset($_POST['c_name1'])) {
    if($_FILES['c_logo']['name']!=""){
        $name=$_FILES['c_logo']['name'];
        $size=$_FILES['c_logo']['size'];
        $tmp=$_FILES['c_logo']['tmp_name'];
        $path="upload/";
        $img=image($name,$size,$tmp,$path);
        $path='upload/'.$_POST['c_logo'];
        unlink($path);
    }
    else{
        $img=$_POST['c_logo'];
    }

  $query = "UPDATE job SET c_logo='".$img."',c_name='".$_POST['c_name1']."',c_title='".$_POST['c_title']."',c_experience='".$_POST['c_experience']."',c_qulification='".$_POST['c_qulification']."',passing_year='".$_POST['passing_year']."',salary='".$_POST['salary']."',salary_type='".$_POST['salary_type']."',link='".$_POST['link']."' WHERE id='".$_POST['id']."'";

  $fire = mysqli_query($conn,$query);

  if ($fire) {
 echo "<script>alert('Data update Successfully...');window.location.href='job_details.php';</script>";
 
    
  }

  else{
    echo "error";

  }

}

// delete
 if (isset($_GET['deleteid'])) {

  
    $query ="DELETE FROM job where id='".$_GET['deleteid']."'";
    $path ='upload/'.$_GET['img'];
       unlink($path);
       $fire =mysqli_query($conn,$query);

      if ($fire) {
 echo "<script>;confirm('are you sure...');window.location.href='job_details.php';</script>";

         
       } 
       else{
        echo "error";
       }
 }



?>

