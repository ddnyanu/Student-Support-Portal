<?php 
include('head.php');
include('cdn.php');

?>
<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>College Details</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <div class="container">
    	<div class="row">
    		<div class="col-md-12">
    			
    			<p>

  <a class="btn btn-primary dropdown" data-toggle="collapse" href="#Add_clg" role="button" aria-expanded="false" aria-controls="Add_clg">
    Add College
  </a>

</p>
<div class="collapse" id="Add_clg">
  <div class="card card-body">
    <form action="query.php" method="post" enctype="multipart/form-data">
     <div class="row">

      <div class="col-md-12"><h1>College Details</h1></div>
     
       <div class="col-md-3">
        <label>Name</label>
        <input type="text" name="clg_name" class="form-control" required>
       </div>

        <div class="col-md-3">
        <label>Logo</label>
        <input type="file" name="clg_logo" class="form-control" required>
       </div>


        <div class="col-md-3">
        <label>Grade</label>
        <input type="text" name="clg_grade" class="form-control" required>
       </div>

        <div class="col-md-3">
        <label>Address</label>
        <input type="text" name="clg_address" class="form-control" required>
       </div>

        <!-- /course part  -->
      <div class="col-md-12"><h1>Course Details</h1></div>
         
         <div class="col-md-3 mt-3">
        <label>Course Name 1</label>
        <input type="text" name="cname_1" class="form-control" required>
       </div> 



        <div class="col-md-3 mt-3">
        <label>Course fees 1</label>
        <input type="text" name="cfees_1" class="form-control" required>
       </div> 


        


       <!-- 2 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 2</label>
        <input type="text" name="cname_2" class="form-control" >
       </div> 


       

        <div class="col-md-3 mt-3">
        <label>Course fees 2</label>
        <input type="text" name="cfees_2" class="form-control" >
       </div> 


         

    <!-- 3 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 3</label>
        <input type="text" name="cname_3" class="form-control" >
       </div> 


       


        <div class="col-md-3 mt-3">
        <label>Course fees 3</label>
        <input type="text" name="cfees_3" class="form-control" >
       </div> 


        

         <!-- 4 -->

          <div class="col-md-3 mt-3">
        <label>Course Name 4</label>
        <input type="text" name="cname_4" class="form-control" >
       </div> 


       


        <div class="col-md-3 mt-3">
        <label>Course fees 4</label>
        <input type="text" name="cfees_4" class="form-control" >
       </div> 


       

       <!-- 5 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 5</label>
        <input type="text" name="cname_5" class="form-control" >
       </div> 


      

        <div class="col-md-3 mt-3">
        <label>Course fees 5</label>
        <input type="text" name="cfees_5" class="form-control" >
       </div> 




       <!-- 6 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 6</label>
        <input type="text" name="cname_6" class="form-control">
       </div> 


        

        <div class="col-md-3 mt-3">
        <label>Course fees 6</label>
        <input type="text" name="cfees_6" class="form-control">
       </div> 



       <!-- 7 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 7</label>
        <input type="text" name="cname_7" class="form-control">
       </div> 


        

        <div class="col-md-3 mt-3">
        <label>Course fees 7</label>
        <input type="text" name="cfees_7" class="form-control">
       </div> 



       <!-- 8 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 8</label>
        <input type="text" name="cname_8" class="form-control">
       </div> 


        

        <div class="col-md-3 mt-3">
        <label>Course fees 8</label>
        <input type="text" name="cfees_8" class="form-control">
       </div> 



       <!-- 9 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 9</label>
        <input type="text" name="cname_9" class="form-control">
       </div> 


        

        <div class="col-md-3 mt-3">
        <label>Course fees 9</label>
        <input type="text" name="cfees_9" class="form-control">
       </div> 



       <!-- 10 -->

        <div class="col-md-3 mt-3">
        <label>Course Name 10</label>
        <input type="text" name="cname_10" class="form-control">
       </div> 


        

        <div class="col-md-3 mt-3">
        <label>Course fees 10</label>
        <input type="text" name="cfees_10" class="form-control">
       </div> 



       



       <!-- facolites part -->

      <div class="col-md-12"><h1>College Details</h1></div>
        
           <!-- facilites 1 -->

         <div class="col-md-3 mt-3">
        <label>Facilites 1</label>
        <input type="text" name="facilites_1" class="form-control" required>
       </div> 

  
           <!-- facilites 2 -->
          
         <div class="col-md-3 mt-3">
        <label>Facilites 2</label>
        <input type="text" name="facilites_2" class="form-control" required>
       </div> 



          <!-- facilites 3 -->
          
         <div class="col-md-3 mt-3">
        <label>Facilites 3</label>
        <input type="text" name="facilites_3" class="form-control" required>
       </div> 


          <!-- facilites 4 -->
          
         <div class="col-md-3 mt-3">
        <label>Facilites 4</label>
        <input type="text" name="facilites_4" class="form-control" required>
       </div> 
    

           <!-- facilites 5 -->
          
         <div class="col-md-3 mt-3">
        <label>Facilites 5</label>
        <input type="text" name="facilites_5" class="form-control">
       </div> 



          <!-- facilites 6 -->
          
         <div class="col-md-3 mt-3">
        <label>Facilites 6</label>
        <input type="text" name="facilites_6" class="form-control">
       </div> 



        


       <div class="col-md-12"><h1> Campus Photos</h1></div>
 
      <!-- img 1  -->

       <div class="col-md-3 mt-3">
        <label>img 1</label>
        <input type="file" name="img_1" class="form-control" required>
       </div> 




        <!-- img 2  -->

       <div class="col-md-3 mt-3">
        <label>img 2</label>
        <input type="file" name="img_2" class="form-control" required>
       </div> 


      


        <!-- img 3  -->

       <div class="col-md-3 mt-3">
        <label>img 3</label>
        <input type="file" name="img_3" class="form-control" required>
       </div> 


       
        <!-- img 4  -->

       <div class="col-md-3 mt-3">
        <label>img 4</label>
        <input type="file" name="img_4" class="form-control">
       </div> 



        <!-- img 5  -->

       <div class="col-md-3 mt-3">
        <label>img 5</label>
        <input type="file" name="img_5" class="form-control">
       </div> 


     

        <!-- img 6  -->

       <div class="col-md-3 mt-3">
        <label>img 6</label>
        <input type="file" name="img_6" class="form-control">

       </div> 


       



       <div class="col-md-12 text-center mt-5">
         <button class="btn btn-secondary" id="button">Submit</button>
       </div>

     </div>
      </form>
    
  </div>
</div>

    		</div>




    <div class="col-md-12">
      <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    
    Collge record
  </a>
 
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
    <div>
 
      <table class="table table-hover table-stripped table-calender">
       
       <tr>
          <th>Sr.no</th>
        <th>Collge Name</th>
        <th>Collge Logo</th>
        <th>Collge Grade</th>
        <th>Collge Address</th>
        <th>Course Name 1</th>
        <th>Course fees 1</th>
        <th>Course Name 2</th>
        <th>Course fees 2</th>
        <th>Course Name 3</th>
        <th>Course fees 3</th>
        <th>Course Name 4</th>
        <th>Course fees 4</th>
        <th>Course Name 5</th>
        <th>Course fees 5</th>
        <th>Course Name 6</th>
        <th>Course fees 6</th>
        <th>Course Name 7</th>
        <th>Course fees 7</th>
        <th>Course Name 8</th>
        <th>Course fees 8</th>
        <th>Course Name 9</th>
        <th>Course fees 9</th>
        <th>Course Name 10</th>
        <th>Course fees 10</th>
        <th>Facilites 1</th>
        <th>Facilites 2</th>
        <th>Facilites 3</th>
        <th>Facilites 4</th>
        <th>Facilites 5</th>
        <th>Facilites 6</th>
        <th>image 1</th>
        <th>image 2</th>
        <th>image 3</th>
        <th>image 4</th>
        <th>image 5</th>
        <th>image 6</th>
        <th>Edit</th>


       </tr>
<?php 
 $query = "SELECT * from college";
include('../database/database.php');
 $fire=mysqli_query($conn,$query);
 $i=1;
 while ($row = mysqli_fetch_assoc($fire)) {


?>



     <form action="query.php" method="post" enctype="multipart/form-data">
       <tr>

         <td><?=$i++;?></td>
         <td><input type="text" name="clg_name1" value="<?=$row['clg_name'];?>" class="form-control"></td>

         <td>
         <input type="hidden" name="id"  value="<?=$row['id'];?>" class="form-control">
         <input type="hidden" name="clg_logo"  value="<?=$row['clg_logo'];?>" class="form-control">
           <input type="file" name="clg_logo">
          <img src="upload/<?=$row['clg_logo'];?>" width="100px">
        </td>

         <td><input type="text" name="clg_grade" value="<?=$row['clg_grade'];?>" class="form-control"></td>
         <td><input type="text" name="clg_address" value="<?=$row['clg_address'];?>" class="form-control"></td>

         <!-- courses  -->
         <td><input type="text" name="cname_1" value="<?=$row['cname_1'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_1" value="<?=$row['cfees_1'];?>" class="form-control"></td>

         <td><input type="text" name="cname_2" value="<?=$row['cname_2'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_2" value="<?=$row['cfees_2'];?>" class="form-control"></td>

         <td><input type="text" name="cname_3" value="<?=$row['cname_3'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_3" value="<?=$row['cfees_3'];?>" class="form-control"></td>


         <td><input type="text" name="cname_4" value="<?=$row['cname_4'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_4" value="<?=$row['cfees_4'];?>" class="form-control"></td>

         <td><input type="text" name="cname_5" value="<?=$row['cname_5'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_5" value="<?=$row['cfees_5'];?>" class="form-control"></td>


         <td><input type="text" name="cname_6" value="<?=$row['cname_6'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_6" value="<?=$row['cfees_6'];?>" class="form-control"></td>

         <td><input type="text" name="cname_7" value="<?=$row['cname_7'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_7" value="<?=$row['cfees_7'];?>" class="form-control"></td>

         <td><input type="text" name="cname_8" value="<?=$row['cname_8'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_8" value="<?=$row['cfees_8'];?>" class="form-control"></td>


         <td><input type="text" name="cname_9" value="<?=$row['cname_9'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_9" value="<?=$row['cfees_9'];?>" class="form-control"></td>

         <td><input type="text" name="cname_10" value="<?=$row['cname_10'];?>" class="form-control"></td>
         <td><input type="text" name="cfees_10" value="<?=$row['cfees_10'];?>" class="form-control"></td>

          <!-- facilites -->

         <td><input type="text" name="facilites_1" value="<?=$row['facilites_1'];?>" class="form-control"></td>
         <td><input type="text" name="facilites_2" value="<?=$row['facilites_2'];?>" class="form-control"></td>
         <td><input type="text" name="facilites_3" value="<?=$row['facilites_3'];?>" class="form-control"></td>
         <td><input type="text" name="facilites_4" value="<?=$row['facilites_4'];?>" class="form-control"></td>
         <td><input type="text" name="facilites_5" value="<?=$row['facilites_5'];?>" class="form-control"></td>
         <td><input type="text" name="facilites_6" value="<?=$row['facilites_6'];?>" class="form-control"></td>

         <!-- images -->

         <td>
          <input type="file" name="img_1">
         <input type="hidden" name="img_1"  value="<?=$row['img_1'];?>" class="form-control">
          <img src="upload/<?=$row['img_1'];?>" width="100px">
        </td>

        <td>
          <input type="file" name="img_2">
         <input type="hidden" name="img_2"  value="<?=$row['img_2'];?>" class="form-control">

          <img src="upload/<?=$row['img_2'];?>" width="100px">
        </td>


        <td>
          <input type="file" name="img_3">
         <input type="hidden" name="img_3"  value="<?=$row['img_3'];?>" class="form-control">

          <img src="upload/<?=$row['img_3'];?>" width="100px">
        </td>


        <td>
          <input type="file" name="img_4">
         <input type="hidden" name="img_4"  value="<?=$row['img_4'];?>" class="form-control">

          <img src="upload/<?=$row['img_4'];?>" width="100px">
        </td>


        <td>
          <input type="file" name="img_5">
         <input type="hidden" name="img_5"  value="<?=$row['img_5'];?>" class="form-control">

          <img src="upload/<?=$row['img_5'];?>" width="100px">
        </td>

        <td>
          <input type="file" name="img_6">
         <input type="hidden" name="img_6"  value="<?=$row['img_6'];?>" class="form-control">

          <img src="upload/<?=$row['img_6'];?>" width="100px">
        </td>

        <td>
          <a href=""><button class="btn btn-warning">Edit</button></a>
          <a href="query.php?deleteid=<?=$row['id'];?>&logo=<?=$row['clg_logo'];?>&img1=<?=$row['img_1'];?>&img2=<?=$row['img_2'];?>&img3=<?=$row['img_3'];?>img4=<?=$row['img_4'];?>&img5=<?=$row['img_5'];?>&img6=<?=$row['img_6'];?>"><button type="button" class="btn btn-danger">Remove</button></a>
        </td>






         
       </tr>

       </form>

       <?php
           }
       ?>


      </table>

    </div>
  </div>
</div>
    </div>    


                  

    	</div>
    </div> <!--  container close -->

   

  </main><!-- End #main -->



</body>


</html>

<!-- <php

// add clg

// echo "<pre>";
// print_r($_POST);
//    $conn=mysqli_connect('localhost','root','','portal');

//        function image($name,$size,$temp,$path)
// {
// $ext=explode(".",$name);
// $a=rand(1,9999)."-college_details.".$ext[count($ext)-1];
// move_uploaded_file($temp,"$path".$a);
// return $a;
// }


$name=$_FILES['clg_logo']['name'];
$size=$_FILES['clg_logo']['size'];
$tmp=$_FILES['clg_logo']['tmp_name'];
$path="upload/";
$clg_logo=image($name,$size,$tmp,$path);

if (empty($_POST['clg_name'])) {
    echo"eroor";
  }
  else{
   $query="INSERT INTO add_college(clg_name,clg_logo,clg_grade,clg_address)VALUES('".$_POST['clg_name']."','".$clg_logo."','".$_POST['clg_grade']."','".$_POST['clg_address']."')";
   
    $fire=mysqli_query($conn,$query);
    if ($fire) {
      // code..
      echo "<script>alert('Success !!!');window.location.href='college_details.php';</script>";
    }

    else{
      echo "eroor";
    }
}


// update

if(isset($_POST['clg_name1'])){
    if($_FILES['clg_logo']['name']!=""){
        $name=$_FILES['clg_logo']['name'];
        $size=$_FILES['clg_logo']['size'];
        $tmp=$_FILES['clg_logo']['tmp_name'];
        $path="upload/";
        $img=image($name,$size,$tmp,$path);
        $path1='upload/'.$_POST['clg_logo'];
        unlink($path1);
    }
    else{
        $img=$_POST['clg_logo'];
    }


$query = "UPDATE add_college SET clg_name='".$_POST['clg_name1']."',clg_logo='".$img."',clg_grade='".$_POST['clg_grade']."',clg_address='".$_POST['clg_address']."' WHERE id='".$_POST['id']."'";
$fire = mysqli_query($conn,$query);

   
    if($fire){
        echo "<script>alert('Data Updated Successfully...');window.location.href='college_details.php';</script>";
    }
    else{
        echo "<script>alert('Data Not Updated...');</script>";
    }
  }

  // delete.

     if (isset($_GET['deleteid'])) {
       $query= "DELETE FROM add_college where id='".$_GET['deleteid']."'";
       $path ='upload/'.$_GET['img'];
       unlink($path1);
       $fire =mysqli_query($conn,$query);
       if($fire){
  echo "<script>alert('Successfully Delete Data');window.location.href='college_details.php';</script>";
}
else{
    echo "error";
}
}

?> -->




