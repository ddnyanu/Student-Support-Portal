
<?php
include('../head.php');

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
 label{
  color:white;
  font-weight:bold;
  font-size:20px;
 }

 body{
 	
   background-image: linear-gradient(to right,#dbc0bf,#c74854);
 }

 .box{
   background-image: linear-gradient(to right,#77804a,#7fb8b4);
   border-radius: 10px;
 }
</style>
</head>
<body>

	<form action="index.php" method="post">
<div class="container">
 <div class="row justify-content-center mt-5 p-5" id="login">
  <div class="col-md-5 box">
 
  <h1 class="text-center mt-5 text-danger">admin Login</h1>

  <label class="ml-2 text-dark">Username:</label>
  <input type="text" name="username" class="form-control">



  <label class="ml-2 text-dark">Password:</label>
  <input type="text" name="password" class="form-control mb-5">

   <div class="col-md-12 text-center mb-5">
     <button class="btn btn-danger">Login</button>
  </div>


  </div>


 </div>
</div>
</form>

</body>
</html>
<?php 
echo "<pre>";
//print_r($_POST);
if (isset($_POST['username'])) {
   $user=trim($_POST['username']);
   $password=trim($_POST['password']);

 $query="SELECT * from admin Where(username='".$user."' AND password='".$password."')";

include('../database/database.php');
   $fire=mysqli_query($conn,$query);
   $row=mysqli_fetch_assoc($fire);
  // print_r($row);

   if($user==$row['username'] && $password==$row['password']){
      //echo "login success";
       //echo $row['name'];
      session_start();
      $_SESSION['name']=$row['name'];
      header('location:dashborad.php');


   }

   else{
      echo "login failed";
   }




}