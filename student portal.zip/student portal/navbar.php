
  <!-- navbar -->
  <div class="info text-white">
    <span class="ml-5"><a href="" class="icons"><i class="fa-solid fa-envelope"></i></a></span>
    <span class="ml-1">studentsupportportal@gmail.com</span>

    <span style="margin-left:80px;"><a href="#" class="icons"><i class="fa-brands fa-linkedin"></i></a></span>
    <span style="margin-left:5px;"><a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a></span>
    <span style="margin-left:5px;"><a href="#" class="icons"><i class="fa-brands fa-facebook"></i></a></span>
    <span style="margin-left:5px;"><a href="#" class="icons"><i class="fa-brands fa-twitter"></i></a></span>
   
    
  </div>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
           <img src="https://www.48hourslogo.com/48hourslogo_data/2020/07/21/99114_1595288437.jpg" style="border-radius: 50%;width: 100px;">
        <a class="navbar-brand" href="#"><h4>Student Support Portal</h4></a>
        <button class="navbar-toggler icon" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
        <a class="nav-link" href="dashboard.php"><h5>Home Page</h5></a>

    
      
        <li class="nav-item">
        <a class="nav-link" href="college.php">
        Academic Details</a>
        </li>

       


        <li class="nav-item">
        <a class="nav-link" href="job_update.php">Job Update</a>
    
        </li>


        <li class="nav-item">
        <a class="nav-link" href="student_feedback.php">Student Feedback</a>
        </li>


        <li class="nav-item" style="margin-left:150px;">
        <span>welcome <span><?php 
                
                 session_start();
                 if (empty($_SESSION['name'])) {
                   header('location:index.php');
                 }
                  echo "<span>".$_SESSION['name']."</span>";
          ?></span></span>

    <span><a href="logout.php" class="text-danger ml-5">logout</a></span>

     
        </li>

        </ul>
        </div>

        </nav>

         <!--  navbar end -->
