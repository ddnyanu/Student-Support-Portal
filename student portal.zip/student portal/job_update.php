<?php

include('head.php');
include('navbar.php');

?>



       <div class="container-fuild company">

         <div class="row">
 
           <div class="col-md-12">
             <marquee scrollamount="20"><h1 class="mt-5 mb-5"> <i>Welcome Student Portal</i> </h1> </marquee>
           </div>

                  
  <?php 
  include('database/database.php');
 $query = "SELECT * from job";

 $fire=mysqli_query($conn,$query);
 $i=1;
 while ($row = mysqli_fetch_assoc($fire)) {


?>
           <div class="col-md-3">
             <div class="card" style="background:#cce7f0; filter: opacity(60%);">

              <div class="card-header">
              <div class="row">
                  
               <div class="col-md-5"><img src="admin/upload/<?=$row['c_logo'];?>" width="100px" style="border-radius: 50%;"></div>
            <div class="col-md-7">  <span style="font-size:20px;font-family: italic;font-weight: bold;"><?=$row['c_name'];?></span>
            </div>

              </div>
              </div>

               <div class="card-body">
<div class="col-md-12"></div>
<div class="col-md-12"><span class="font-weight-bold">Job Role: </span> <span class="h5 text-danger"><?=$row['c_title'];?></span></div>
<div class="col-md-12"><span class="font-weight-bold">Experience:</span> <span class="h5 text-info"><?=$row['c_experience'];?></span></div>
<div class="col-md-12"><span class="font-weight-bold">Qulification: </span><span class="h5 text-info"><?=$row['c_qulification'];?></span></div>
<div class="col-md-12"><span class="font-weight-bold">Year of Passing:</span> <span class="h5 text-info"><?=$row['passing_year'];?></span></div>
<div class="col-md-12"><span class="font-weight-bold">Salary:</span> <span class="h5 text-info"><?=$row['salary'];?>/-<?=$row['salary_type'];?></span></div>
<div class="col-md-12"><span class="font-weight-bold">Link:</span> <span class="h5 text-info"><a href="<?=$row['link'];?>"><?=$row['link'];?></a></span></div>
               </div>
             </div>
           </div>

          


           <?php 


         }
         ?>
            


         </div>
          
       </div>  <!-- conatainer close -->

         

       </body>
       </html>
