<?php

include('head.php');
include('navbar.php');

?>

  <!-- <Marquee class="mt-5"><h2>Welcome To Student Support Portal</h2></Marquee> -->
<div class="container-fluid mt-5 mb-5">
  <div class="row">

    <div class="col-md-6" data-aos="fade-up">
      <h1 class="mt-5"><b>Enroll for AdmissionAssist<sup>TM</sup></b></h1>
      <p class="highlight">Get assured admission to undergraduate colleges that suit your profile.</p>
      <h4 class="text-primary mt-5"><marquee scrollamount="25" behavior="scroll" onmouseover="this.stop();" onmouseout="this.start()">Choice The Favoirte College Campus and see the your fees structure</marquee></h4>
    </div>

    <div class="col-md-6" data-aos="fade-up">
      <img  src="assest/banner1.png">
    </div>
  </div><!-- row end -->



  <div class="row mt-5">

    <div class="col-md-5 mt-5" data-aos="fade-up">
      <img src="assest/banner2.jpg">
    </div>

    <div class="col-md-7 mt-4" data-aos="fade-up">
      <h2>AdmissionAssist<sup>TM</sup></h2>
      <p class="highlight">A Professional Admission Guidance and Support for College Admissions in India</p>

      <p class="detail">There are over 1000 universities and 40,000 colleges offering more than 600 courses of study in colleges for making 1,000 plus careers in India. However, for admission into many courses such as engineering, medicine, law, management, hotel management etc, several entrance exams need to be written. In addition, there many variations in courses and their admission process across colleges and universities across India. What’s more, there are several changes that are getting introduced in the higher education system, practically every year.<br><br>

All this becomes very confusing for the student when he or she goes to seek a college admission. And as if that is not enough, one mistake on part of the student in following the admission process and it is all over. The application is rejected! The need of the hour is professional college admission guidance and support for college admissions in India. And that is what the AdmissionAssist™ service is.</p>
    </div>

  </div><!-- row end -->

 
        <div class="row mt-5">
        <div class="col-md-6 mt-5 " data-aos="fade-up">
        <h1><b>AdmissionAssist<sup>TM</sup> Offers</b></h1>
        <p class="highlight">A Professional Admission Guidance and Support for College Admissions in India</p>

        <ul class="detail">

        <li>Assurance of a college admission that best matches the student’s profile in terms of potential, performance and preference by implementing a smart shortlisting strategy which is totally customised for each student.</li>

        <li>The student to be spoilt for choices with a wide spectrum of courses and colleges with over 600 courses in over 1000 universities and 40,000 colleges to choose from across India.</li>

        <li>ne of a kind service since the last 10 years and there is no one else offering such a service in India.</li>

        </ul>
        </div>

        <div class="col-md-6 mt-5" data-aos="fade-up">
        <img src="assest/banner3.png">
        </div>


        </div><!-- row end-->


        <div class="row mt-5">
          <div class="col-md-6 mt-5" data-aos="fade-up">
            <h1><b>The benefits of AdmissionAssist<sup>TM</sup></b></h1>

            <ul class="mt-5 detail">

              <li>Increased awareness of opportunities and higher education alternatives for chosen careers.</li>

              <li>Objective counselling on options for college admissions after class XII based on career choices.</li>

              <li>
                Opportunity to evaluate courses and colleges hitherto unknown to students and parents.
              </li>

              <li>Professional advice to make informed career and college admission related decisions.</li>

              <li>Lower stress and anxiety as higher education alternatives and backups for desired careers are evaluated and planned for.</li>

              <li>A sense of purpose leading to higher motivation and competitiveness.</li>
              <li>Early clarity for taking needed coaching and prepare for relevant entrance exams from class XI itself or in summer holidays.</li>
             

            </ul>
          </div>

          <div class="col-md-6" data-aos="fade-up">
            <img src="assest/banner4.jpg" width="500px" style="border-radius: 10px;">
          </div>
          
        </div><!-- row end -->

</div><!-- container close -->

<!--  footer start  -->
<div class="container-fluid bg-light mt-5 copyright">
  <div class="row">
    
     <div class="col-md-12 text-center" data-aos="fade-up">
          
           <img src="assest/logo.png" width="200px">

           <!-- <h3 class="text-center font">DD & SK</h3> -->
           <h6 class="text-center ">Copyright 2022 ©Student Support Portal®, All Rights Reserved</h6>


     </div>

  </div><!-- row end -->
</div> <!-- container end -->




 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>



</body>
</html>