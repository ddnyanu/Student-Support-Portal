<?php

include('head.php');
include('database/database.php');


?>


<form action="index.php" method="post">
<div class="container">
	<div class="row justify-content-center mt-5 p-5" id="login">
		<div class="col-md-5">
			<div class="card bg-info">
				<div class="card-header">
					<h1 class="text-center font-weight-bold text-warning text-Uppercase "> User Login</h1>
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-md-12">
							<label>Username :</label>
							<input type="text" name="username" class="form-control" required="">
							<label>Password :</label>
							<input type="text" name="password" class="form-control" required="">
						</div>
						<div class="col-md-12 card-footer text-center mt-3">
							<button class="btn btn-warning">Login</button>
						</div>
					</div>
				</div>
			<div class="card-footer text-center">
				<b class="text-white">New User<a href="student_registration.php">Register Here</a> </b>
			</div>
			</div>
		</div>
	</div>
</div>
</form>
				
		

</body>
</html>



<?php
// print_r($_POST);

   
 if(isset($_POST['username']))
 {
 	$user=trim($_POST['username']);
 	$password=trim($_POST['password']);
 	$query="SELECT * from student where(email='".$user."' OR mobile='".$user."') AND pass='".$password."'";
 	
 	
 	$q=mysqli_query($conn,$query);
 	$ar=mysqli_fetch_assoc($q);
 	// print_r($ar);
 	if(($user==$ar['mobile'] || $user==$ar['email']) &&
 	 $password==$ar['pass'])
 	{
 		// echo "login success";
 		session_start();
 		$_SESSION['name']=$ar['name'];
 		header('location:dashboard.php');
 	}
 	else
 	{
 		echo "login failed";
 	}
 }
 
?>