<?php

include('head.php');


?>



<form action="student_registration.php" method="post">
<div class="container">
	<div class="row justify-content-center mt-5 p-5" id="login">
		<div class="col-md-8">
			<div class="card bg-info">
				<div class="card-header">
					<h1 class="text-center font-weight-bold text-warning text-Uppercase ">New User Registration Form</h1>
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<label>Name :</label>
							<input type="text" name="name" class="form-control" required>
						</div>
						<div class="col-md-6">
							<label>Email :</label>
							<input type="text" name="email" class="form-control" required>
						</div>
						<div class="col-md-6">
							<label>Mobile :</label>
							<input type="text" name="mobile" class="form-control" required>
						</div>
							
							
						<div class="col-md-6">
							<label>Address :</label>
							<input type="text" name="address" class="form-control" required>
						</div>
						<div class="col-md-6">
							<label>Password :</label>
							<input type="text" name="pass" class="form-control" required>
						</div>
						<div class="col-md-6">
							<label>Confirm Password :</label>
							<input type="text" name="confirm_pass" class="form-control" required>
						</div>
						<div class="col-md-12 card-footer text-center mt-3">
							<button class="btn btn-warning">Save Now</button>
						</div>
					</div>
				</div>
			<div class="card-footer text-center">
				<b class="text-white">Old User<a href="index.php">Login Here</a> </b>
			</div>
			</div>
		</div>
	</div>
</div>
</form>

</body>
</html>


<?php
//print_r($_POST);
if (isset($_POST['name'])){
	if ($_POST['pass']==$_POST['confirm_pass']){
include('database/database.php');
$query="INSERT INTO student(name,email,mobile,address,pass) VALUES ('".$_POST['name']."','".$_POST['email']."','".$_POST['mobile']."','".$_POST['address']."','".$_POST['pass']."') ";
$fire=mysqli_query($conn,$query);
if($fire){
	header('location:index.php');
}
else{
	echo "not Register";
}
}
	else{
		echo "not Match Password and confirm password....";
}
}
?>