-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Aug 07, 2024 at 06:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`) VALUES
(1, 'admin@gmail.com', 'admin123', 'hruta'),
(3, 'hruta@gmail.com', '1234', 'dnyanu');

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `id` int(11) NOT NULL,
  `clg_name` text NOT NULL,
  `clg_logo` text NOT NULL,
  `clg_grade` text NOT NULL,
  `clg_address` text NOT NULL,
  `cname_1` text NOT NULL,
  `cfees_1` text NOT NULL,
  `cname_2` text NOT NULL,
  `cfees_2` text NOT NULL,
  `cname_3` text NOT NULL,
  `cfees_3` text NOT NULL,
  `cname_4` text NOT NULL,
  `cfees_4` text NOT NULL,
  `cname_5` text NOT NULL,
  `cfees_5` text NOT NULL,
  `cname_6` text NOT NULL,
  `cfees_6` text NOT NULL,
  `cname_7` text NOT NULL,
  `cfees_7` text NOT NULL,
  `cname_8` text NOT NULL,
  `cfees_8` text NOT NULL,
  `cname_9` text NOT NULL,
  `cfees_9` text NOT NULL,
  `cname_10` text NOT NULL,
  `cfees_10` text NOT NULL,
  `facilites_1` text NOT NULL,
  `facilites_2` text NOT NULL,
  `facilites_3` text NOT NULL,
  `facilites_4` text NOT NULL,
  `facilites_5` text NOT NULL,
  `facilites_6` text NOT NULL,
  `img_1` text NOT NULL,
  `img_2` text NOT NULL,
  `img_3` text NOT NULL,
  `img_4` text NOT NULL,
  `img_5` text NOT NULL,
  `img_6` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`id`, `clg_name`, `clg_logo`, `clg_grade`, `clg_address`, `cname_1`, `cfees_1`, `cname_2`, `cfees_2`, `cname_3`, `cfees_3`, `cname_4`, `cfees_4`, `cname_5`, `cfees_5`, `cname_6`, `cfees_6`, `cname_7`, `cfees_7`, `cname_8`, `cfees_8`, `cname_9`, `cfees_9`, `cname_10`, `cfees_10`, `facilites_1`, `facilites_2`, `facilites_3`, `facilites_4`, `facilites_5`, `facilites_6`, `img_1`, `img_2`, `img_3`, `img_4`, `img_5`, `img_6`) VALUES
(2, 'Arts Commerce and Science College Sonai', '2877-college_datails.jfif', 'A+', 'Sonai', 'BSC', '23000', 'MSC', '2300', 'B.COM', '1200', 'M.COM', '45000', 'BA', '1200', 'MA ', '12,00', 'BCA', '25,000', 'BBA', '1,0000', 'B.Voc Food Processing', '.....', 'B.Voc Hospitality and Tourism', '......', 'Boys Hostel', 'Girls Hostel', 'Library', 'Auditorium', 'IT Infrastructure', 'Alumni Associations', '5504-college_datails.jfif', '9830-college_datails.png', '8627-college_datails.jpg', '7183-college_datails.jpg', '3267-college_datails.jpg', '1949-college_datails.jpg'),
(5, 'sant Dnyaneshwar College Newasa', '3176-college_datails.jpg', 'A+', 'Newsa', 'BSC', '23000', 'MSC', '2300', 'B.COM', '1200', 'M.COM', '45000', 'BA', '1200', 'MA ', '12,00', 'BCA', '25,000', '', '', '', '', '', '', 'Auditorium', 'Girls Hostel', 'Library', 'Alumni Associations', 'IT Infrastructure', '', '4536-college_datails.jpg', '4902-college_datails.jpg', '2216-college_datails.jpg', '5800-query.', '5739-query.', '9540-query.'),
(6, 'Jijamata College of Science and Arts, Bhende', '7506-college_datails.jpg', 'a', 'Bhende', 'B.Sc', '15,000', 'BA', '6,000', 'B.Com', '8,000', 'B.Sc Computer Science', '12,000', 'MA Economics', '5,000', 'MA Marathi', '5,000', 'M.Sc Analytical Chemistry', '20,000', 'M.Sc Botany', '20,000', '', '', '', '', 'Boys Hostel', 'Girls Hostel', 'Library', 'Auditorium', 'IT Infrastructure', 'Alumni Associations', '2688-college_datails.jpg', '2253-college_datails.jpg', '7620-query.png', '1161-query.jpg', '3075-query.jpg', '8399-query.'),
(15, 'atal bihari vajpayee homeopathic medical college', '3573-college_datails.jpg', 'A+', 'Khadaka Fata', 'BHMS', '45,000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Boys Hostel', 'Girls Hostel', 'Library', 'Auditorium', 'IT Infrastructure', 'Alumni Associations', '6965-college_datails.jpg', '5521-college_datails.jpg', '4373-college_datails.jpg', '4502-college_datails.jpg', '2230-college_datails.jpg', '4177-query.'),
(16, 'New Arts, Commerce and Science College,Ahemdnagar', '1037-college_datails.jpg', 'A+', 'Ahemdnagar', 'B.Sc', '45,000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Boys Hostel', 'Girls Hostel', 'Library', 'Alumni Associations', 'IT Infrastructure', 'Alumni Associations', '3873-college_datails.jpeg', '3781-college_datails.jpeg', '4034-college_datails.jpeg', '3553-college_datails.', '8676-college_datails.', '619-college_datails.'),
(17, 'R. B. Narayanrao Borawake College, Shrirampur', '3058-college_datails.jpg', 'A', 'Shrirampur', 'BSC', '23000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Boys Hostel', 'Girls Hostel', 'Library', 'Auditorium', '5', 'Alumni Associations', '8918-college_datails.jpeg', '3677-college_datails.jpeg', '9335-college_datails.jpeg', '6366-college_datails.', '1364-college_datails.', '8209-college_datails.');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `photo` text NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `class` text NOT NULL,
  `messege` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `photo`, `name`, `address`, `class`, `messege`) VALUES
(10, '2894-feedback.jpeg', 'Abhishek Dahitule', 'kanguni', 'TYBCA', 'very helpful website'),
(11, '2075-feedback.jpeg', 'Mahesh More', 'Sonai', 'TYBCA', '#-- nice website --#'),
(12, '422-feedback.jpeg', 'Kunal Ukirde', 'Rastapur', 'TYBCA', 'Please add some new Future.'),
(13, '8966-feedback.jpeg', 'Ketan Mate Patil', 'Pravarasangam', 'TYBCA', 'very great website \r\n');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `id` int(11) NOT NULL,
  `c_logo` text NOT NULL,
  `c_name` text NOT NULL,
  `c_title` text NOT NULL,
  `c_experience` text NOT NULL,
  `c_qulification` text NOT NULL,
  `passing_year` text NOT NULL,
  `salary` text NOT NULL,
  `salary_type` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `c_logo`, `c_name`, `c_title`, `c_experience`, `c_qulification`, `passing_year`, `salary`, `salary_type`, `link`) VALUES
(19, '5136-job.jpg', 'PayPal', 'Software Engineer', '	Freshers', 'BE/BTech/MTech', '2023/2024', 'Not Disclosed', 'Per Annum', 'https://www.jobsorigin.com/2020/11/paypal-hiring-freshers-for-se-position.html'),
(20, '7771-job.jpg', 'Tata Communication', 'Customer Service Executive', '0-2 Years', 'Any Degree', '2020/2021/2022', '3,00,000 - 4,00,000/- ', 'Per Annum', 'https://www.jobsorigin.com/2021/04/tata-communications-off-campus-drive.html'),
(21, '942-job.jpg', 'Hawkins', 'Management Trainee', 'Experience/ Fresher', '	BE/BTech/MCA/MBA/ Any Degree', '2022', 'â‚¹8 to â‚¹10 Lakhs', 'Per Annum', 'https://www.jobsorigin.com/2020/11/paypal-hiring-freshers-for-se-position.html'),
(22, '8553-job.png', 'Wipro', '	WILP', 'freshers', 'BSc/BCA', '2022/2023', 'â‚¹15,488 - â‚¹23,000/-', 'Per Annum', 'https://www.jobsorigin.com/2021/04/tata-communications-off-campus-drive.html');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `address` text NOT NULL,
  `pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `mobile`, `address`, `pass`) VALUES
(6, 'Vaibhav', 'h@gmail.com', '143143143', 'Mumbai', '143'),
(7, 'Dnyaneshwar Kailas Dhotre', 'd@gmail.com', '07756003145', 'Usthal dumala', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `college`
--
ALTER TABLE `college`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
